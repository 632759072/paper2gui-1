# Accessibility

【Quick Entry:[Review](readme_en.md) # [Video Comparison Tool] (video_compare.md) # [中文] (readme.md)]

## Developer Reviews
> Video overshoots, frameshifting, keying, etc. often requiring contrast effects, so I developed this video comparison tool.
> 
## Introduction

Supports centering, horizontal, or vertical comparison of two videos.

## Effect Demo:

! [](.. /docs/images/video_compare.png)

## Speed PK

## Creative PK

## Reference