# 图片抠图

【快捷入口：[综述](readme.md) # [RVM](rvm_gui.md) 】

## 开发者评价
> 截至2022年5月，图片抠图已屡见不鲜，但是AI抠图技术依然很出色，目前主要以人像抠图技术为主。
## 简介

抠图，一键去除背景，保留人像。抠图细节基本满意。

## 效果演示：

![](https://github.com/PeterL1n/RobustVideoMatting/raw/master/documentation/image/showreel.gif)

## 速度PK


## 创意PK



## 参考

- [PeterL1n/RobustVideoMatting](https://github.com/PeterL1n/RobustVideoMatting)
- [Tencent/ncnn](https://github.com/Tencent/ncnn)
- [Naive-ui](https://www.naiveui.com/zh-CN/os-theme)
- [wailsapp/wails](https://github.com/wailsapp/wails)
- [Baiyuetribe/paper2gui](https://github.com/Baiyuetribe/paper2gui)