# 目标检测

【快捷入口：[综述](readme.md) # [YOLOv5](yolov5_gui.md) # [YOLOX](yolox_gui.md) # [YOLOv6](yolov6_gui.md)   】

## 开发者评价
> 截至2022年5月，yolo系列成为目标检测、追踪、识别等等常用工具。
## 简介



## 效果演示：

本系列APP支持单张图片或视频处理，采用NCNN底层推理框架，可自定义模型

## 速度PK


## 创意PK


## 参考

- [ultralytics/yolov5/](https://github.com/ultralytics/yolov5)
- [Tencent/ncnn](https://github.com/Tencent/ncnn)
- [Naive-ui](https://www.naiveui.com/zh-CN/os-theme)
- [wailsapp/wails](https://github.com/wailsapp/wails)
- [Baiyuetribe/paper2gui](https://github.com/Baiyuetribe/paper2gui)