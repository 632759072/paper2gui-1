# Object Detection

【Quick Entry:[Overview](readme.md) # [YOLOv5](yolov5_gui.md) # [YOLOX](yolox_gui.md) # [YOLOv6](yolov6_gui.md) # [中文] (readme.md)】

## Developer Comments:
> As of May 2022, the yolo series has become a common tool for object detection, tracking, identification etc...
## Brief OVerview:
> Automatic video keying by AI. Which can be used for creating transparent maps or putting a green/blue/red screen behind certain objects,anime characters,cartoon.


## Demonstration of tool：

This series of APPS supporting single images or video processing, adopting the underlying inference framework of NCNN allowing customization of the model.

## Speed PK:


## Creative PK:


## References:

- [ultralytics/yolov5/](https://github.com/ultralytics/yolov5)
- [Tencent/ncnn](https://github.com/Tencent/ncnn)
- [Naive-ui](https://www.naiveui.com/zh-CN/os-theme)
- [wailsapp/wails](https://github.com/wailsapp/wails)
- [Baiyuetribe/paper2gui](https://github.com/Baiyuetribe/paper2gui)