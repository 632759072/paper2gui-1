# 视频抠图

【快捷入口：[综述](readme.md) # [MODNet](modnet_gui.md) # [MobileNetV2](mobilenetv2_gui.md) 】

## 开发者评价
> 截至2022年5月，视频抠图基本成熟，可以应对比较复杂的实物场景，其中尤其以RVM为代表。
## 简介

视频抠图，一键生成绿幕。该系列所有工具均已支持图片和视频抠图。

## 效果演示：

![](https://github.com/PeterL1n/RobustVideoMatting/raw/master/documentation/image/showreel.gif)

## 速度PK


## 创意PK



## 参考

- [ZHKKKe/MODNet](https://github.com/ZHKKKe/MODNet)
- [PeterL1n/RobustVideoMatting](https://github.com/PeterL1n/RobustVideoMatting)
- [Tencent/ncnn](https://github.com/Tencent/ncnn)
- [Naive-ui](https://www.naiveui.com/zh-CN/os-theme)
- [wailsapp/wails](https://github.com/wailsapp/wails)
- [Baiyuetribe/paper2gui](https://github.com/Baiyuetribe/paper2gui)